package com.pool.test.testcase.sign;

import com.google.protobuf.MessageLite;
import com.offbynull.coroutines.user.Continuation;
import com.pool.Response;
import com.pool.network.RobotNetNode;
import com.pool.protobuf.PbClientMsg;
import com.pool.protobuf.PbCommonDef;
import com.pool.protobuf.PbMsgCode;
import com.pool.test.core.Register;
import com.pool.test.core.TestCase;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

public class SignDataTest extends TestCase {


    public void registerMsg(Register<MessageLite, Response> funcRegister) {
        funcRegister.register
                (PbMsgCode.msgcode.SC_SIGN_DATA.getNumber(),
                        PbClientMsg.SC_SIGN_DATA.getDefaultInstance(),
                        new SignDataJob());
    }

    @Override
    public void unRegisterMsg(Consumer<Integer> funcUnregister) {
        funcUnregister.accept(PbMsgCode.msgcode.CS_SIGN_DATA.getNumber());
    }


    public void doRunTests(Continuation c) {

        PbClientMsg.CS_SIGN_DATA.Builder rq = PbClientMsg.CS_SIGN_DATA.newBuilder();
        rq.setNow(1625190710249L + 5*24*3600*1000L);
        client.sendMsg(PbMsgCode.msgcode.CS_SIGN_DATA.getNumber(), rq.build());
    }



    //================================================
    private class SignDataJob extends TestCaseResponse{

        @Override
        public void run() {
            PbClientMsg.SC_SIGN_DATA msg = this.getMessage();
            System.out.println(msg);
            System.out.println("/:::::::::signDataGet::::::::::-----------");
            for (Map.Entry<Integer, PbCommonDef.PbSign> signEntry : msg.getSigns().getDataMap().entrySet()) {
                List<Integer> historyList = signEntry.getValue().getRewardHistoryList();
                System.out.println("id: " + signEntry.getKey() + " values: "+ historyList);
            }

            System.out.println(":::::::::signDataGet::::::::::-----------/");
        }
    }

}

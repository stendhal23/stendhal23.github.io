package com.pool.codec;

import java.util.List;

import com.pool.common.packet.Packet;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageEncoder;
import io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame;

public class PbEncoder extends MessageToMessageEncoder<Packet> {
	@Override
	protected void encode(ChannelHandlerContext ctx, Packet packet, List<Object> out) throws Exception {
		// TODO Auto-generated method stub
		ByteBuf buf = Unpooled.buffer();
		buf.writeShort(10 + (packet.getBytes() != null ? packet.getBytes().length : 0));
		buf.writeShort(packet.getCmd());
		//buf.writeShort(packet.getGameId());
		buf.writeInt(packet.getSeq());
		if (packet.getBytes() != null && packet.getBytes().length > 0) {
			buf.writeBytes(packet.getBytes());
		}
		out.add(new BinaryWebSocketFrame(buf));
	}
}
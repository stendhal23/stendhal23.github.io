package com.pool;

import java.util.ArrayList;
import java.util.List;

import com.pool.common.util.LogUtil;

public class RobotHub {
	private static volatile RobotHub instance = null;

	public static RobotHub getInstance() {
		if (instance == null) {
			synchronized (RobotHub.class) {
				if (instance == null) {
					instance = new RobotHub();
				}
			}
		}
		return instance;
	}

	// 线程组
	private List<RobotThread> threadList = new ArrayList<RobotThread>();
	private int numThread = 0;
	private int numRobot = 0;
	/*private String ip;
	private int port = 0;*/
	public void start(int numThread, int numRobot) {
		this.numThread = numThread;
		this.numRobot = numRobot;
		
		for (int i = 0; i < this.numThread; ++i) {
			RobotThread thread = new RobotThread();
			threadList.add(thread);
		}

		for (int i = 0; i < threadList.size(); ++i) {
			threadList.get(i).init(this.numRobot);
			LogUtil.SYSTEM.info("{} start...", threadList.get(i).getName());
		}

		LogUtil.SYSTEM.info("RobotHub start success");
	}

	public void stop() {
		for (int i = 0; i < threadList.size(); ++i) {
			LogUtil.SYSTEM.info("{} shutdown...", threadList.get(i).getName());
			try {
				threadList.get(i).close();
			} catch (Exception e) {
				LogUtil.SYSTEM.error(e);
			}
		}
	}

}

package com.pool;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.pool.common.util.LogUtil;
import com.pool.robot.Robot;

public class RobotHandler {
	private MessageLite msglite = null;

	private Response resp = null;

	public Response getResponse() {
		return resp;
	}

	public RobotHandler(MessageLite msglite, Response resp, Robot robot) {
		this.msglite = msglite;
		this.resp = resp;
		this.resp.init(robot);
	}

	public MessageLite parseFrom(byte[] bytes) {
		try {
			return msglite.getParserForType().parseFrom(bytes);
		} catch (InvalidProtocolBufferException e) {
			LogUtil.SYSTEM.error("RobotMsg parseFrom exception->", e);
		}
		return null;
	}
}

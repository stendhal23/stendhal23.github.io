package com.pool.test.core;

import com.offbynull.coroutines.user.Continuation;
import com.offbynull.coroutines.user.Coroutine;
import com.offbynull.coroutines.user.CoroutineRunner;

public abstract class MyCoroutine implements Coroutine {

    private CoroutineRunner runner;
    private boolean finished;

    public MyCoroutine() {
        this.runner = new CoroutineRunner(this);
    }

    @Override
    final public void run(Continuation c) throws Exception {
        doRun(c);
        this.finished = true;
    }

    protected abstract void doRun(Continuation c);

    private Object val;

    //======================================

    public Object resume()
    {
        return resume(null);
    }

    public Object resume(Object val)
    {
        if(finished){
            throw new IllegalStateException("coroutine finished");
        }
        this.val = val;
        this.runner.execute();
        return this.val;
    }

    public Object yield(Continuation c){
        return yield(c, null);
    }

    public Object yield(Continuation c, Object val)
    {
        this.val = val;
        c.suspend();
        return this.val;
    }

    public boolean isFinished() {
        return finished;
    }

}

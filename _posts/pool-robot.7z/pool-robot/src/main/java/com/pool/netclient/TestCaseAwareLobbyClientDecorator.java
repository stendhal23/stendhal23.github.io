package com.pool.netclient;

import com.google.protobuf.MessageLite;
import com.pool.Response;
import com.pool.netclient.LobbyClient;
import com.pool.test.core.MyTestRunner;

public class TestCaseAwareLobbyClientDecorator extends LobbyClient {

    private LobbyClient agent;
    private MyTestRunner testRunner = new MyTestRunner();;

    public TestCaseAwareLobbyClientDecorator(LobbyClient agent) {
        super(agent.robot);
        this.agent = agent;
        testRunner.setRegister(this::_register);
    }


    private void _register(int id, MessageLite message, Response response){
        registerMsg(id, message, response, robot);
    }

    //============================================
    private boolean isFinishedTestsInRobotIdleState = false;
    @Override
    protected void actionIdle() {
        if(!isFinishedTestsInRobotIdleState){
            isFinishedTestsInRobotIdleState = this.testRunner.testsInIdleState(this, robot.getId());
            return;
        }
        agent.actionIdle();
    }
}

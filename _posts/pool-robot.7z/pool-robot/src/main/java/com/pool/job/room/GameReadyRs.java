package com.pool.job.room;

import com.pool.Response;
import com.pool.common.util.LogUtil;


public class GameReadyRs extends Response {
    @Override
    public void run() {
        LogUtil.SYSTEM.info("{}准备游戏成功", robot.getData().getNick());
        //robot.setRoomReady(true);
    }
}

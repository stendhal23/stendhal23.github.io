package com.pool.define.state;

public class LobbyNetState {
	// --------------------------------------------------
	// 状态
	// 账号登录中
	public final static int AUTHING = 0;
	// 连接中
	public final static int CONNECTING = 1;
	// 已连接,未登录
	public final static int CONNECTED = 2;
	// 已连接,已登录
	public final static int LOGINED = 3;
	// 已连接,关闭中
	public final static int CLOSING = 4;
	// --------------------------------------------------
}
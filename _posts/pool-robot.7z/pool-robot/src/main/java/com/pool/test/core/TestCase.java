package com.pool.test.core;

import com.google.protobuf.MessageLite;
import com.offbynull.coroutines.user.Continuation;
import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.network.RobotNetNode;
import com.pool.protobuf.PbClientMsg;
import com.pool.protobuf.PbCommonDef;
import com.pool.protobuf.PbMsgCode;
import org.apache.commons.lang3.exception.ExceptionUtils;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;


@SuppressWarnings("rawtypes, unchecked")
public abstract class TestCase{

    public static final int NEW = TestCaseState.NEW.value;
    public static final int RUNNING = TestCaseState.RUNNING.value;
    public static final int SUCCESS = TestCaseState.SUCCESS.value;
    public static final int FAIL = TestCaseState.FAIL.value;
    public static final int TIMEOUT = TestCaseState.TIMEOUT.value;

    protected static final long TIMEOUTMILLI = 50000L;

    protected String reason = "";

    protected AtomicInteger state = new AtomicInteger(NEW);

    protected ScheduledExecutorService es = Executors.newScheduledThreadPool(2);

    //=====================================
    protected MyCoroutine coroutine;


    public TestCase() {
        this.coroutine = new MyCoroutine() {
            @Override
            public void doRun(Continuation c) {
                try {
                    doRunTests(c);
                } catch (Throwable e){
                    fail(ExceptionUtils.getStackTrace(e));
                    return;
                } finally {
                    doAfter();
                }
                success();
            }
        };
    }

    //======================================

    protected abstract void registerMsg(Register<MessageLite, Response> funcRegister);

    protected abstract void unRegisterMsg(Consumer<Integer> funcUnregister);

    protected void doAfter(){
        PbClientMsg.CS_GM_CLEAN_MODULE.Builder rqCleanModules = PbClientMsg.CS_GM_CLEAN_MODULE.newBuilder();
        //-------------------
        rqCleanModules.setModule(-1);       // -1: ALL 2:RoleGoods, 3:RoleTreasure, 4: RoleSettings 5:RoleQuests 6:RoleCueStick 7:RoleArchive 8:RoleSign
        client.sendMsg(PbMsgCode.msgcode.CS_GM_CLEAN_MODULE.getNumber(), rqCleanModules.build());
    };


    //======================================
    private Queue queue = new LinkedList();
    protected RobotNetNode client;

    public int runTests(RobotNetNode client){
        // if is first running, submit Timeout job
        if(this.state.compareAndSet(NEW, RUNNING)){
            this.client = client;
            es.schedule(this::timeout, TIMEOUTMILLI, TimeUnit.MILLISECONDS);
            coroutine.resume();
        }
        // if not running
        if(this.state.get() != RUNNING){
            return state.get();
        }

        // the test case is still running.  tick the coroutine
        if(!coroutine.isFinished() && !queue.isEmpty()) {
            coroutine.resume(queue.poll());
        }
        return state.get();
    }

    protected abstract void doRunTests(Continuation c) throws Exception;

    protected void timeout() {
        state.compareAndSet(RUNNING, TIMEOUT);
    }

    public TestCaseState getState(){
        return TestCaseState.forNum(state.get());
    }

    //=======================================
    protected void success()
    {
        if(!state.compareAndSet(RUNNING, SUCCESS)) {
            LogUtil.SYSTEM.info(" success {}", this);
        }
    }

    protected void fail(String reason)
    {
       this.reason = reason;
        if(!state.compareAndSet(RUNNING, FAIL)) {
            LogUtil.SYSTEM.error(" test case failed {}", this);
        }
    }

    private void pushMsg(Object msg) {
        this.queue.offer(msg);
    }

    @Override
    public String toString() {
        return "TestCase{" +
                "reason='" + reason + '\'' +
                ", state=" + TestCaseState.forNum(state.get()).toString() +
                '}';
    }

    //==========================
    public enum TestCaseState {
        NEW(0, "\uD83C\uDD95"),     //🆕
        RUNNING(1, "\uD83C\uDFC3"), //🏃
        SUCCESS(2, "\uD83D\uDDF8"), //🗸
        FAIL(3, "\uD83D\uDEAB"),  //🚫
        TIMEOUT(4, "\uD83D\uDD5B"), //🕛
        UNKNOWN(0xffff, "UNKNOWN"),
        ;

        private final int value;
        private final String emoji;

        TestCaseState(int value, String emoji) {
            this.value = value;
            this.emoji = emoji;
        }

        public int getValue() {
            return value;
        }

        public String getEmoji() {
            return emoji;
        }

        public static TestCaseState forNum(int value) {
            switch (value) {
                case 0:
                    return NEW;
                case 1:
                    return RUNNING;
                case 2:
                    return SUCCESS;
                case 3:
                    return FAIL;
                case 4:
                    return TIMEOUT;
                default:
                    return UNKNOWN;
            }
        }
    }

    //========================================
    protected class TestCaseResponse extends Response{

        @Override
        public void run() {
            pushMsg(getMessage());
        }

        @Override
        public void error(int cmd, int errcode) {
            PbCommonDef.errcode err = PbCommonDef.errcode.forNumber(errcode);
            LogUtil.SYSTEM.error("{} {}", this, err.toString());
            pushMsg(err);
        }

    }
}

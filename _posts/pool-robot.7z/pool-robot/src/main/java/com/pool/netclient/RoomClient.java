package com.pool.netclient;

import com.pool.IBehaviour;
import com.pool.common.actor.ICallback;
import com.pool.common.util.LogUtil;
import com.pool.define.state.RoomActionState;
import com.pool.define.state.RoomNetState;
import com.pool.job.HeartbeatRs;
import com.pool.job.SysOfflineNtf;
import com.pool.job.room.EnterRoomNtf;
import com.pool.job.room.GameBoutNtf;
import com.pool.job.room.GameReadyRs;
import com.pool.job.room.GameStartRs;
import com.pool.job.room.LeaveRoomNtf;
import com.pool.job.room.RoomEnterRs;
import com.pool.job.room.RoomLeaveRs;
import com.pool.job.room.RoomStateNtf;
import com.pool.network.RobotNetNode;
import com.pool.protobuf.PbClientMsg.CS_GAME_START;
import com.pool.protobuf.PbClientMsg.CS_ROOM_ENTER;
import com.pool.protobuf.PbClientMsg.CS_SYS_HEARTBEAT;
import com.pool.protobuf.PbClientMsg.SC_GAME_BOUT_NTF;
import com.pool.protobuf.PbClientMsg.SC_GAME_READY;
import com.pool.protobuf.PbClientMsg.SC_GAME_START;
import com.pool.protobuf.PbClientMsg.SC_ROOM_ENTER;
import com.pool.protobuf.PbClientMsg.SC_ROOM_ENTER_NTF;
import com.pool.protobuf.PbClientMsg.SC_ROOM_LEAVE;
import com.pool.protobuf.PbClientMsg.SC_ROOM_LEAVE_NTF;
import com.pool.protobuf.PbClientMsg.SC_ROOM_STATE_NTF;
import com.pool.protobuf.PbClientMsg.SC_SYS_HEARTBEAT;
import com.pool.protobuf.PbClientMsg.SC_SYS_OFFLINE_NTF;
import com.pool.protobuf.PbMsgCode.msgcode;
import com.pool.robot.Robot;

public class RoomClient extends RobotNetNode {
	private Behaviour behaviour = new Behaviour();
	private Robot robot;

	private long pingTime;

	// 连接状态
	private int nstateValue;
	private long nstateTime;
	// 行为状态
	private int astateValue;
	private long astateTime;

	public void changeNs(int state) {
		this.nstateValue = state;
		this.nstateTime = System.currentTimeMillis();
	}

	public void changeAs(int state) {
		this.astateValue = state;
		this.astateTime = System.currentTimeMillis();
	}

	public RoomClient(Robot robot) {
		this.robot = robot;
		this.initMsg();
	}

	@Override
	protected void initMsg() {
		registerMsg(msgcode.SC_SYS_OFFLINE_NTF.getNumber(), SC_SYS_OFFLINE_NTF.getDefaultInstance(),
				new SysOfflineNtf(), robot);
		registerMsg(msgcode.SC_SYS_HEARTBEAT.getNumber(), SC_SYS_HEARTBEAT.getDefaultInstance(), new HeartbeatRs(),
				robot);

		registerMsg(msgcode.SC_ROOM_ENTER.getNumber(), SC_ROOM_ENTER.getDefaultInstance(), new RoomEnterRs(), robot);

		registerMsg(msgcode.SC_ROOM_LEAVE.getNumber(), SC_ROOM_LEAVE.getDefaultInstance(), new RoomLeaveRs(), robot);
		registerMsg(msgcode.SC_GAME_READY.getNumber(), SC_GAME_READY.getDefaultInstance(), new GameReadyRs(),
				robot);
		registerMsg(msgcode.SC_GAME_START.getNumber(), SC_GAME_START.getDefaultInstance(), new GameStartRs(),
				robot);
		registerMsg(msgcode.SC_ROOM_ENTER_NTF.getNumber(), SC_ROOM_ENTER_NTF.getDefaultInstance(), new EnterRoomNtf(),
				robot);
		registerMsg(msgcode.SC_ROOM_LEAVE_NTF.getNumber(), SC_ROOM_LEAVE_NTF.getDefaultInstance(), new LeaveRoomNtf(),
				robot);
		registerMsg(msgcode.SC_ROOM_STATE_NTF.getNumber(), SC_ROOM_STATE_NTF.getDefaultInstance(), new RoomStateNtf(),
				robot);

		registerMsg(msgcode.SC_GAME_BOUT_NTF.getNumber(), SC_GAME_BOUT_NTF.getDefaultInstance(), new GameBoutNtf(),
				robot);
	}

	public void run() {
		handleMsg();

		ping();

		switch (this.nstateValue) {
		case RoomNetState.CONNECTING:
			nstateConnecting();
			break;
		case RoomNetState.CONNECTED:
			nstateConnected();
			break;
		case RoomNetState.ENTERING:
			nstateEntering();
			break;
		case RoomNetState.ENTERED:
			nstateEntered();
			break;
		}
	}

	private void ping() {
		if (System.currentTimeMillis() >= this.pingTime + 5000) {
			CS_SYS_HEARTBEAT.Builder rq = CS_SYS_HEARTBEAT.newBuilder();
			this.sendMsg(msgcode.CS_SYS_HEARTBEAT.getNumber(), rq.build());
			this.pingTime = System.currentTimeMillis();
		}
	}

	private void nstateConnecting() {
		// TODO Auto-generated method stub
		if (System.currentTimeMillis() >= this.nstateTime + 5000) {
			this.nstateTime = System.currentTimeMillis();
			String[] host = robot.getData().getSearchNtf().getRoomHost().split(":");
			this.host = host[0];
			this.port = Integer.parseInt(host[1]);
			this.startConnect(new ICallback() {
				@Override
				public void onResult(Object x) {
					// TODO Auto-generated method stub
					changeNs(RoomNetState.CONNECTED);
					LogUtil.SYSTEM.info("{} 连接ROOM服务器成功.", robot.getName());
				}
			});
		}
	}

	private void nstateConnected() {
		// TODO Auto-generated method stub
		if (System.currentTimeMillis() >= this.nstateTime + 5000) {
			this.nstateTime = System.currentTimeMillis();

			CS_ROOM_ENTER.Builder msg = CS_ROOM_ENTER.newBuilder();
			msg.setToken(robot.getData().getSearchNtf().getToken());
			this.sendMsg(msgcode.CS_ROOM_ENTER.getNumber(), msg.build());
			changeNs(RoomNetState.ENTERING);
		}
	}

	private void nstateEntering() {

	}

	private void nstateEntered() {
		switch (astateValue) {
		case RoomActionState.IDLE:
			astateIdle();
			break;
		case RoomActionState.STARTING:
			astateStarting();
			break;
		case RoomActionState.STARTED:
			astateStarted();
			break;
		default:
			break;
		}
	}
	
	private void astateIdle() {
		behaviour.exec(new IBehaviour() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				CS_GAME_START.Builder msg = CS_GAME_START.newBuilder();
				sendMsg(msgcode.CS_GAME_START.getNumber(), msg.build());
				changeAs(RoomActionState.STARTING);
			}
		});
		
	}
	
	private void astateStarting() {
		
	}
	
	private void astateStarted() {
		
	}
}

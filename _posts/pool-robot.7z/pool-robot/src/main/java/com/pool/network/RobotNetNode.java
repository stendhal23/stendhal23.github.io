package com.pool.network;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.protobuf.MessageLite;
import com.pool.Response;
import com.pool.RobotHandler;
import com.pool.common.actor.ICallback;
import com.pool.common.network.NetNode;
import com.pool.common.network.codec.MessageDecoder;
import com.pool.common.network.codec.MessageEncoder;
import com.pool.common.packet.Packet;
import com.pool.common.packet.PacketCreator;
import com.pool.common.util.EnvUtil;
import com.pool.common.util.LogUtil;
import com.pool.protobuf.PbMsgCode.msgcode;
import com.pool.robot.Robot;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.buffer.Unpooled;
import io.netty.channel.*;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.epoll.EpollSocketChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.timeout.IdleStateHandler;

public abstract class RobotNetNode extends NetNode {
	private long connectStart = 0;

	private static final EventLoopGroup sharedEventLoopGroup;
	static {
		if (EnvUtil.isWindows()) {
			sharedEventLoopGroup = new NioEventLoopGroup();
		} else {
			sharedEventLoopGroup = new EpollEventLoopGroup();
		}
	}

	public Channel getChannel() {
		return channel;
	}

	protected Channel channel = null;
	private ICallback onConnectedCb = null;

	public RobotNetNode() {
		super("robot", "robot");
		// TODO Auto-generated constructor stub
	}

	public void sessionActive(ChannelHandlerContext ctx) throws Exception {
		this.channel = ctx.channel();
	}

	public void sessionInactive(ChannelHandlerContext ctx) {
		this.channel = null;
	}

	public void messageReceived(ChannelHandlerContext ctx, Packet packet) {
		msgQueue.add(packet);
	}

	private void send(Packet packet, ICallback callback) {
		try {
			if (channel != null) {
				channel.writeAndFlush(packet);
			}
		} catch (Exception e) {
			LogUtil.SYSTEM.error("RobotNetNode.send -> occur exception", e);
		}
	}

	public void sendMsg(int code, MessageLite message, ICallback callback) {
		Packet packet = null;
		if (message == null) {
			packet = PacketCreator.create((short) code, new byte[0]);
		} else {
			packet = PacketCreator.create((short) code, message.toByteArray());
		}
		send(packet, callback);
	}

	public void sendMsg(int code, MessageLite message) {
		sendMsg(code, message, null);
	}

	public void startConnect(ICallback callback) {
		this.bootstrap = new Bootstrap();

		this.bootstrap.group(sharedEventLoopGroup);
		if (EnvUtil.isWindows()) {
			this.bootstrap.channel(NioSocketChannel.class);
		} else {
			this.bootstrap.channel(EpollSocketChannel.class);
		}
		this.bootstrap.option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT);
		this.bootstrap.option(ChannelOption.SO_KEEPALIVE, true);
		this.bootstrap.option(ChannelOption.TCP_NODELAY, true);
		this.bootstrap.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 30000);
		this.bootstrap.handler(new ChannelInitializer<Channel>() {
			@Override
			protected void initChannel(Channel ch) throws Exception {
				ch.pipeline().addLast(new OneTimeAttachOptionalHeader());
				ch.pipeline().addLast(new IdleStateHandler(15, 15, 15));
				ch.pipeline().addLast(new MessageDecoder());
				ch.pipeline().addLast(new MessageEncoder());
				ch.pipeline().addLast(new RobotChannelHandler(RobotNetNode.this));
			}
		});
		connectServer(callback);
	}

	public void connectServer(ICallback callback) {
		LogUtil.SYSTEM.info("start connecting {}:{}", this.host, this.port);
		connectStart = System.currentTimeMillis();
		final ChannelFuture future = bootstrap.connect(this.host, this.port);
		future.addListener(new ChannelFutureListener() {
			@Override
			public void operationComplete(ChannelFuture future) throws Exception {
				if (!future.isSuccess()) {
				} else {
					long cost = System.currentTimeMillis() - connectStart;
					LogUtil.SYSTEM.warn("连接建立成功,{}:{}, 耗时{}ms", RobotNetNode.this.host, RobotNetNode.this.port, cost);
					if (callback != null) {
						callback.onResult(null);
					}
				}
			}
		});
	}

	// =====================================================================
	private List<Packet> msgQueue = new ArrayList<>();
	private Map<Integer, RobotHandler> msgMap = new HashMap<Integer, RobotHandler>();

	protected final void reset() {
		this.channel.close();
		this.msgQueue.clear();
	}

	protected void registerMsg(int code, MessageLite msg, Response resp, Robot robot) {
		msgMap.put(code, new RobotHandler(msg, resp, robot));
	}

	public void unRegisterMsg(int code) {
		msgMap.remove(code);
	}

	protected void handleMsg() {
		while (!msgQueue.isEmpty()) {
			Packet packet = msgQueue.get(0);
			if (packet != null) {
				RobotHandler robotHandler = msgMap.get((int) packet.getCmd());
				if (robotHandler == null) {
					LogUtil.SYSTEM.error("undefined msg cmd={},{}", packet.getCmd(),
							msgcode.forNumber(packet.getCmd()));
					msgQueue.remove(0);
					continue;
				}

				Response resp = robotHandler.getResponse();
				if (resp != null) {
					resp.msg();
					if (packet.getError() == 0) {
						MessageLite msg = robotHandler.parseFrom(packet.getBytes());
						if (msg != null) {
							resp.success(msg);
						}
					} else {
						resp.error(packet.getCmd(), packet.getError());
					}
				}
			}
			msgQueue.remove(0);
		}
	}

	protected abstract void initMsg();

	private class OneTimeAttachOptionalHeader extends ChannelInboundHandlerAdapter {

		@Override
		public void channelActive(ChannelHandlerContext ctx) throws Exception {
			byte[] header = getHeader();
			if(header != null)
			{
				ByteBuf byteBuf = Unpooled.copiedBuffer(header);
				ctx.channel().write(byteBuf);
				ctx.channel().flush(); // TODO flush
			}
			ctx.channel().pipeline().remove(this);
			super.channelActive(ctx);
		}


		@Override
		public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
			LogUtil.SYSTEM.error(cause.getStackTrace());
			super.exceptionCaught(ctx, cause);
		}
	}

	protected byte[] getHeader(){return null;};
}

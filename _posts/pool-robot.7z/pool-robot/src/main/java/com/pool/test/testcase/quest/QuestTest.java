package com.pool.test.testcase.quest;

import com.google.protobuf.MessageLite;
import com.offbynull.coroutines.user.Continuation;
import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.common.util.TimeUtil;
import com.pool.protobuf.PbClientMsg;
import com.pool.protobuf.PbCommonDef;
import com.pool.protobuf.PbCommonDef.errcode;
import com.pool.protobuf.PbMsgCode;
import com.pool.test.core.Register;
import com.pool.test.core.TestCase;
import org.junit.Assert;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class QuestTest extends TestCase {


    @Override
    public void registerMsg(Register<MessageLite, Response> funcRegister) {
        funcRegister.register
                (PbMsgCode.msgcode.SC_QUEST_RESET.getNumber(),
                        PbClientMsg.SC_QUEST_RESET.getDefaultInstance(),
                        new QuestTest.QuestResetRes());
        funcRegister.register
                (PbMsgCode.msgcode.SC_QUEST_UPDATE.getNumber(),
                        PbClientMsg.SC_QUEST_UPDATE.getDefaultInstance(),
                        new QuestTest.QuestUpdateRes());
        funcRegister.register
                (PbMsgCode.msgcode.SC_QUEST_COMPLETE.getNumber(),
                        PbClientMsg.SC_QUEST_COMPLETE.getDefaultInstance(),
                        new QuestTest.QuestCompleteRes());
        funcRegister.register
                (PbMsgCode.msgcode.SC_QUEST_GET.getNumber(),
                        PbClientMsg.SC_QUEST_GET.getDefaultInstance(),
                        new QuestTest.QuestGetRes());
        funcRegister.register
                (PbMsgCode.msgcode.SC_AWARDS_LIST_NTF.getNumber(),
                        PbClientMsg.SC_AWARDS_LIST_NTF.getDefaultInstance(),
                        new QuestTest.AwardNTFJobRes());
    }

    @Override
    public void unRegisterMsg(Consumer<Integer> funcUnregister) {
        funcUnregister.accept(PbMsgCode.msgcode.SC_QUEST_RESET.getNumber());
        funcUnregister.accept(PbMsgCode.msgcode.SC_QUEST_UPDATE.getNumber());
        funcUnregister.accept(PbMsgCode.msgcode.SC_QUEST_COMPLETE.getNumber());
        funcUnregister.accept(PbMsgCode.msgcode.SC_QUEST_GET.getNumber());
        funcUnregister.accept(PbMsgCode.msgcode.SC_AWARDS_LIST_NTF.getNumber());
    }

    @Override
    public void doRunTests(Continuation c) throws Exception {

        PbClientMsg.SC_AWARDS_LIST_NTF award;
        PbClientMsg.SC_QUEST_GET getResponse;
        PbClientMsg.SC_QUEST_RESET resetResponse;
        PbClientMsg.SC_QUEST_COMPLETE completeResponse;
        Map<Integer, PbCommonDef.PbQuest> oldQuests = Collections.EMPTY_MAP;
        Map<Integer, PbCommonDef.PbQuest> quests;
        errcode err;


        PbClientMsg.CS_QUEST_RESET.Builder rqReset = PbClientMsg.CS_QUEST_RESET.newBuilder();
        PbClientMsg.CS_QUEST_UPDATE.Builder rqUpdate = PbClientMsg.CS_QUEST_UPDATE.newBuilder();
        PbClientMsg.CS_QUEST_COMPLETE.Builder rqComplete = PbClientMsg.CS_QUEST_COMPLETE.newBuilder();
        PbClientMsg.CS_QUEST_GET.Builder rqGet = PbClientMsg.CS_QUEST_GET.newBuilder();




        //-------------------
        client.sendMsg(PbMsgCode.msgcode.CS_QUEST_GET.getNumber(), rqReset.build());

        getResponse = (PbClientMsg.SC_QUEST_GET) coroutine.yield(c);

        Assert.assertEquals(3, getResponse.getQuests().getQuestsCount());
        Assert.assertEquals(1, getResponse.getQuests().getResetCnt());
        quests = getResponse.getQuests().getQuestsMap();
        Assert.assertTrue(quests.values().stream().noneMatch(q -> q.getFinished()));

        //-------------------
        oldQuests = quests;
        client.sendMsg(PbMsgCode.msgcode.CS_QUEST_RESET.getNumber(), rqReset.build());


        resetResponse = (PbClientMsg.SC_QUEST_RESET) coroutine.yield(c);

        Assert.assertEquals(3, resetResponse.getQuests().getQuestsCount());
        Assert.assertEquals(0, resetResponse.getQuests().getResetCnt());
        quests = resetResponse.getQuests().getQuestsMap();
        if(oldQuests.equals(quests))
        {
            List<Integer> collectold = oldQuests.values().stream().map(PbCommonDef.PbQuest::getQid).collect(Collectors.toList());
            List<Integer> collectnew = quests.values().stream().map(PbCommonDef.PbQuest::getQid).collect(Collectors.toList());
            LogUtil.SYSTEM.error("**************** old: {}, new:{}", collectold, collectnew);
        }
        Assert.assertTrue(!oldQuests.equals(quests));
        oldQuests = quests;

        //-------------------
        client.sendMsg(PbMsgCode.msgcode.CS_QUEST_RESET.getNumber(), rqReset.build());

        err = (errcode) coroutine.yield(c);
        Assert.assertEquals(errcode.QUEST_RESET_COUNT_NOT_ENOUGH, err);


        //--------------------------------- test quest update
        int qid = 0;
        //-------------------
        {
            qid = -123456;
            PbCommonDef.PbQuest.Builder builder = PbCommonDef.PbQuest.newBuilder();
            builder.setQid(qid);
            builder.setProgress(3);
            builder.build();
            rqUpdate.addQuests(builder);
        }
        client.sendMsg(PbMsgCode.msgcode.CS_QUEST_UPDATE.getNumber(), rqUpdate.build());


        err = (errcode) coroutine.yield(c);;
        Assert.assertEquals(errcode.QUEST_NOT_EXIST, err);

        //--------------
        for (PbCommonDef.PbQuest quest : quests.values()) {

            qid = quest.getQid();
            PbCommonDef.PbQuest.Builder builder = PbCommonDef.PbQuest.newBuilder();
            builder.setQid(qid);
            builder.setProgress(3);
            builder.build();

            rqUpdate.clear();
            rqUpdate.addQuests(builder);
            break;
        }
        client.sendMsg(PbMsgCode.msgcode.CS_QUEST_UPDATE.getNumber(), rqUpdate.build());
        rqComplete.setId(qid);
        client.sendMsg(PbMsgCode.msgcode.CS_QUEST_COMPLETE.getNumber(), rqComplete.build());

        Object obj = coroutine.yield(c);
        Object obj1 = coroutine.yield(c);
        System.out.println(obj);
        System.out.println(obj1);



    }


    //================================================
    private class QuestResetRes extends TestCaseResponse{}
    private class QuestUpdateRes extends TestCaseResponse{}
    private class QuestCompleteRes extends TestCaseResponse{}
    private class QuestGetRes extends TestCaseResponse{}
    private class AwardNTFJobRes extends TestCaseResponse{}

}

package com.pool.define;

public class LoginResponse {
	private String openId;
	private int lobby;
	private String param;
	private String lobbyHost;
	
	public String getOpenId() {
		return openId;
	}
	public void setOpenId(String openId) {
		this.openId = openId;
	}
	public int getLobby() {
		return lobby;
	}
	public void setLobby(int lobbyId) {
		this.lobby = lobbyId;
	}	
	public String getLobbyHost() {
		return lobbyHost;
	}
	public void setLobbyHost(String host) {
		this.lobbyHost = host;
	}
	public String getParam() {
		return param;
	}
	public void setParam(String param) {
		this.param = param;
	}
}

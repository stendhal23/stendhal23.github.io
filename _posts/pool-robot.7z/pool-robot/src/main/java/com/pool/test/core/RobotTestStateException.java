package com.pool.test.core;

import java.util.Arrays;

public class RobotTestStateException extends RuntimeException{

    public RobotTestStateException() {
    }

    public RobotTestStateException(String testcase_failed_, Object...args) {
        super(testcase_failed_ + Arrays.toString(args));
    }
}

package com.pool.test.core;


@FunctionalInterface
public interface Register <M, R> {

    void register(int id, M message, R response);
}

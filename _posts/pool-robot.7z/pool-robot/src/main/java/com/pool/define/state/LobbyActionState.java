package com.pool.define.state;

public class LobbyActionState {
	// --------------------------------------------------
	// 状态
	// 空闲
	public final static int IDLE = 0;
	// 发起匹配
	public final static int SEARCHING = 1;
	// 匹配成功
	public final static int SEARCH_SUCCESS = 2;
	// 登记请求
	public final static int ROOM_CHECK_IN = 3;
	// 登记成功
	public final static int ROOM_CHECK_IN_SUCCESS = 4;
	// 游戏状态中
	public final static int ROOM_GAME = 5;
	// --------------------------------------------------
}
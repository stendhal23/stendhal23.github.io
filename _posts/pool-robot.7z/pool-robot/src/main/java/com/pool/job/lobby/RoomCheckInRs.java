package com.pool.job.lobby;

import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.define.state.LobbyActionState;

public class RoomCheckInRs extends Response {
	@Override
	public void run() {
		LogUtil.SYSTEM.info("{}房间登记成功", robot.getData().getNick());
		this.robot.changeLobbyAs(LobbyActionState.ROOM_CHECK_IN_SUCCESS);
	}
	
	@Override
    public void error(int cmd, int errcode) {
		LogUtil.SYSTEM.info("{}房间登记失败", robot.getData().getNick());
		this.robot.changeLobbyAs(LobbyActionState.SEARCH_SUCCESS);
	}
}

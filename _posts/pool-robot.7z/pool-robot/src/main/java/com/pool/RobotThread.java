package com.pool;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.pool.common.util.EnvUtil;
import com.pool.common.util.LogUtil;
import com.pool.robot.Robot;

public class RobotThread extends Thread {
    private Map<Long, Robot> robotMap = new ConcurrentHashMap<Long, Robot>();

    private volatile boolean running = false;

    @Override
    public void run() {
        while (running) {
            try {
                Iterator<Map.Entry<Long, Robot>> it = this.robotMap.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<Long, Robot> entry = it.next();
                    entry.getValue().run();
                }
            } catch (Exception e) {
                LogUtil.SYSTEM.error(e);
            }

            EnvUtil.sleep(5);
        }
    }

    public Robot get(Long id) {
        return robotMap.get(id);
    }

    public void init(int robotnum) {        
        for (int i = 0; i < robotnum; ++i) {
            Robot robot = new Robot();
            this.robotMap.put(robot.getId(), robot);
        }
        running = true;
        this.start();
    }

    public void close() {
        this.running = false;
    }
}

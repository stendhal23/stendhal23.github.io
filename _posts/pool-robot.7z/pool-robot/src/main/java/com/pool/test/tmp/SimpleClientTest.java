package com.pool.test.tmp;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.buffer.Unpooled;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * exceptionCaught 里如果报 " An established connection was aborted by the software in "  的话, 有可能是防火墙做的。
 * 关掉 360, 金山毒霸
 *
 */
public class SimpleClientTest {


    public static void main(String[] args) throws InterruptedException {


        Bootstrap b = new Bootstrap();

        b.group(new NioEventLoopGroup()).channel(NioSocketChannel.class)
                .option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
                .option(ChannelOption.SO_KEEPALIVE, true)
                .option(ChannelOption.TCP_NODELAY, true)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 30000)
        .handler(new ChannelInitializer<Channel>() {

            @Override
            protected void initChannel(Channel ch) throws Exception {
                ch.pipeline().addLast(new SimpleHandler());
            }
        });

//        ChannelFuture connect = b.connect("127.0.0.1", 8000);
        ChannelFuture connect = b.connect("10.10.9.42", 8008);   // HAProxy
//        ChannelFuture connect = b.connect("192.168.234.129", 8081);   // HAProxy
//        ChannelFuture connect = b.connect("127.0.0.1", 15010);   // local lobby
//        ChannelFuture connect = b.connect("10.10.9.42", 8080);  // direct connect to http server
        connect.sync();
    }


    private static ScheduledExecutorService es = Executors.newScheduledThreadPool(1);




    @ChannelHandler.Sharable
    public static class SimpleHandler extends ChannelInboundHandlerAdapter {


        @Override
        public void channelActive(ChannelHandlerContext ctx) throws Exception {

            super.channelActive(ctx);
            System.out.println("hello channel active");

//            testSendInt(ctx);
//            testSendString(ctx);
//            testSendHTTPGet(ctx);
            testSendLobbyIdPrefixed(ctx);

            System.out.println("sent");

            ctx.channel().flush();

        }


        @Override
        public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
            ByteBuf bb = (ByteBuf) msg;
            System.out.println("client channel read " + bb.toString(StandardCharsets.UTF_8));
            super.channelActive(ctx);

            ByteBuf byteBuf = Unpooled.copyInt(92);
            es.schedule(() ->  ctx.channel().writeAndFlush(byteBuf).addListener(writeAndFlush_failed), 1000, TimeUnit.MILLISECONDS);


        }



        //===================================================

        @Override
        public void channelInactive(ChannelHandlerContext ctx) throws Exception {
            System.out.println("client: channel inactive");
            super.channelInactive(ctx);
        }

        @Override
        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
            super.exceptionCaught(ctx, cause);
            cause.printStackTrace();
        }



        //============================================= Simple Tests

        private void testSendInt(ChannelHandlerContext ctx) {
            ByteBuf byteBuf = Unpooled.copyInt(92);
            ctx.channel().writeAndFlush(byteBuf).addListener(s ->{
                if(!s.isSuccess()){
                    System.err.println("writeAndFlush failed");
                }
            });
        }

        private void testSendString(ChannelHandlerContext ctx) {
            ByteBuf byteBuf = Unpooled.copiedBuffer("oooooooov1dev1from simple client", StandardCharsets.UTF_8);
            Runnable header = () -> ctx.channel().writeAndFlush(Unpooled.copiedBuffer(" remaining http header \r\n", StandardCharsets.UTF_8));
            es.schedule(header, 1000, TimeUnit.MILLISECONDS);
            ctx.channel().writeAndFlush(byteBuf).addListener(s ->{
                if(!s.isSuccess()){
                    System.err.println("writeAndFlush failed");
                }
            });
        }

        private void testSendHTTPGet(ChannelHandlerContext ctx) {
            String ss = "GET / HTTP/1.1\r\n" +
                    "Content-Type: text/plain\r\n" +
                    "Content-Length: 12\r\n" +
                    "\r\n" +
                    "query_string";
            ctx.channel().writeAndFlush(Unpooled.copiedBuffer(ss, StandardCharsets.UTF_8)).addListener(s ->{
                if(!s.isSuccess()){
                    System.err.println("writeAndFlush failed");
                }
            });
        }


        private void testSendLobbyIdPrefixed(ChannelHandlerContext ctx) {
            ByteBuf byteBuf = Unpooled.copyInt(91);   //这个必须直接与 haproxy 上配置的 acl 对应, 否则连接会被 haproxy 关闭。 这个是整个 stream 的头 4 个字节。 后续 channelRead 时不必再带上
            ctx.channel().write(byteBuf);

            ByteBuf byteBuf1 = Unpooled.copyInt(999);
            ctx.channel().write(byteBuf1);

            ctx.channel().flush();


//            Runnable writeRandomMsg = () ->{
//                ByteBuf randMsg = Unpooled.copiedBuffer("random msg: " + ThreadLocalRandom.current().nextInt(), StandardCharsets.UTF_8);
//                ctx.channel().writeAndFlush(randMsg).addListener(writeAndFlush_failed);
//            };
//            es.scheduleAtFixedRate(writeRandomMsg, 3000,2000, TimeUnit.MILLISECONDS);

        }


        GenericFutureListener<? extends Future<? super Void>> writeAndFlush_failed = future -> {
            if(!future.isSuccess()){
                System.out.println("writeAndFlush failed");
                future.cause().printStackTrace();
            }
        };

    }
}

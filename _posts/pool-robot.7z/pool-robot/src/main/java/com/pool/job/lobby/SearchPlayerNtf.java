package com.pool.job.lobby;

import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.define.state.LobbyActionState;
import com.pool.protobuf.PbClientMsg.SC_SEARCH_PLAYER_NTF;
import com.pool.protobuf.PbCommonDef.PbeSearchResult;

public class SearchPlayerNtf extends Response {
    @Override
    public void run() {
        SC_SEARCH_PLAYER_NTF msg = getMessage();       
        if (msg.getFail() == 0) {        	
            LogUtil.SYSTEM.info("{}收到通知,匹配成功,{}", robot.getData().getNick(), msg);            
            robot.getData().setSearchNtf(msg);
            this.robot.changeLobbyAs(LobbyActionState.SEARCH_SUCCESS);
        } else {
            LogUtil.SYSTEM.info("{}收到通知,匹配失败,原因{}", robot.getData().getNick(), PbeSearchResult.forNumber(msg.getFail()));
            this.robot.changeLobbyAs(LobbyActionState.IDLE);
        }
    }
}

package com.pool.define.state;

public class RoomActionState {
	public final static int IDLE = 0;
	//public final static int 
	public final static int STARTING = 1;
	
	public final static int STARTED = 2;
}

package com.pool.define.state;

public class RoomNetState {
	public final static int CONNECTING = 0;
	
	public final static int CONNECTED = 1;
	
	public final static int ENTERING = 2;
	
	public final static int ENTERED = 3;
}

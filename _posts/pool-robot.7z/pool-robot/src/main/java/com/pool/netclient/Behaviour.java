package com.pool.netclient;

import com.pool.IBehaviour;

public class Behaviour {
	private long behaveTime = 0;

	public boolean exec(IBehaviour behaviour) {
		if (System.currentTimeMillis() >= this.behaveTime + 3000) {
			this.behaveTime = System.currentTimeMillis();
			behaviour.run();
			return true;
		} else {
			return false;
		}
	}
}

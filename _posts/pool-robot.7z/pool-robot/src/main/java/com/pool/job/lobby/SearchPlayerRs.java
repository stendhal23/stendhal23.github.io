package com.pool.job.lobby;

import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.define.state.LobbyActionState;

public class SearchPlayerRs extends Response {
    @Override
    public void run() {
        LogUtil.SYSTEM.info("{}匹配请求发起完成,等待匹配结果中...", robot.getData().getNick());
    }
    
    @Override
    public void error(int cmd, int errcode) {
    	LogUtil.SYSTEM.info("{}匹配请求发起失敗", robot.getData().getNick());
    	this.robot.changeLobbyNs(LobbyActionState.IDLE);
    }
}

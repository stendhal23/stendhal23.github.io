package com.pool.job.room;

import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.protobuf.PbClientMsg.SC_ROOM_ENTER_NTF;
import com.pool.protobuf.PbCommonDef.PbRoomPlayer;

public class EnterRoomNtf extends Response {
    @Override
    public void run() {
        SC_ROOM_ENTER_NTF msg = getMessage();
        PbRoomPlayer newPlayer = msg.getPlayer();
        if (newPlayer != null) {
            LogUtil.SYSTEM.info("{}收到通知,{}进入房间", robot.getData().getNick(), newPlayer.getBasic().getNick());
        }
    }
}

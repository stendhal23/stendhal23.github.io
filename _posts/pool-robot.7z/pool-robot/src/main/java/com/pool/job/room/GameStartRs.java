package com.pool.job.room;

import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.define.state.RoomActionState;

public class GameStartRs extends Response {
    @Override
    public void run() {
        LogUtil.SYSTEM.info("{}场景加载完成,开始游戏", robot.getData().getNick());
        robot.changeRoomAs(RoomActionState.STARTED);
    }
}

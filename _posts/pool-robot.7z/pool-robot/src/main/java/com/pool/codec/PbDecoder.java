package com.pool.codec;

import java.util.List;

import com.pool.common.packet.Packet;
import com.pool.common.packet.PacketCreator;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageDecoder;
import io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame;

public class PbDecoder extends MessageToMessageDecoder<BinaryWebSocketFrame> {
	@Override
	protected void decode(ChannelHandlerContext ctx, BinaryWebSocketFrame msg, List<Object> out) throws Exception {
		ByteBuf in = msg.content();
		// 读取传送过来的消息的长度。
		int length = in.readUnsignedShort();
		short cmd = in.readShort();
		short err = in.readShort();
		int contentLenth = length - 6;
		byte[] bytes = new byte[contentLenth];
		in.readBytes(bytes, 0, contentLenth);

		Packet packet = PacketCreator.create(cmd, err, bytes);

		packet.setLength(length);
		out.add(packet);
	}


}
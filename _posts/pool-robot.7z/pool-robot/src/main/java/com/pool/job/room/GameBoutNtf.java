package com.pool.job.room;

import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.protobuf.PbClientMsg.SC_GAME_BOUT_NTF;
import com.pool.protobuf.PbCommonDef.PbGameBout;

public class GameBoutNtf extends Response {
    @Override
    public void run() {
        SC_GAME_BOUT_NTF msg = getMessage();
        PbGameBout bout = msg.getBout();
        if (bout != null) {
            LogUtil.SYSTEM.info("{}收到通知,游戏回合切换至玩家{}", robot.getData().getNick(), bout.getRoleid());
        }
    }
}

package com.pool.test.tmp;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.buffer.Unpooled;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.haproxy.HAProxyMessage;
import io.netty.handler.codec.haproxy.HAProxyMessageDecoder;
import io.netty.handler.codec.haproxy.HAProxyProtocolException;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class SimpleServer {


    public static void main(String[] args) {

        int port = Integer.parseInt(System.getProperty("port"));

        ServerBootstrap b = new ServerBootstrap();
        b.group(new NioEventLoopGroup());
        b.channel(NioServerSocketChannel.class)
                .option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
                .option(ChannelOption.SO_KEEPALIVE, true)
                .option(ChannelOption.TCP_NODELAY, true)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 30000)
                .childHandler(new ChannelInitializer<Channel>() {
                    @Override
                    protected void initChannel(Channel ch) throws Exception {
                        ch.pipeline()
                                .addLast(new HAProxyMessageDecoder())
                                .addLast(new HeaderStripper())
                                .addLast(new SimpleHandler());
                    }
        });

        b.bind(port);


    }

    private static class HeaderStripper extends ChannelInboundHandlerAdapter{
        @Override
        public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
            if(msg instanceof HAProxyMessage)
            {
                System.out.println("HAProxy message received");
            }else if(msg instanceof ByteBuf){
                ByteBuf bb = (ByteBuf) msg;
                if(bb.isReadable(4)){   //strip the first 4 bytes, then remove self from the pipeline,  forward whatever remains in the bytebuf to the normal msg decoder
                    System.out.println("striped: " + bb.readInt());
                    ctx.channel().pipeline().remove(this);
                    ByteBuf byteBuf = Unpooled.copiedBuffer("ok from " + Integer.parseInt(System.getProperty("port")), StandardCharsets.UTF_8);
                    ctx.channel().writeAndFlush(byteBuf);
                    super.channelRead(ctx, bb);
                }
            }else {
                System.out.println("impossible !");
            }
        }
    }

    private static class SimpleHandler extends ChannelInboundHandlerAdapter {


        @Override
        public void channelActive(ChannelHandlerContext ctx) throws Exception {
            System.out.println("channel active ");
        }

        @Override
        public void channelInactive(ChannelHandlerContext ctx) throws Exception {
            System.out.println("channel inactive ");
        }

        @Override
        public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
            ByteBuf bb = (ByteBuf) msg;
            System.out.println("received msg: " + bb.readInt());
            bb.resetReaderIndex();
            System.out.println("received msg: " + bb.toString(Charset.forName("utf8")));

            ByteBuf byteBuf = Unpooled.copiedBuffer("hello from " + Integer.parseInt(System.getProperty("port")), StandardCharsets.UTF_8);
            ctx.channel().writeAndFlush(byteBuf);
        }
    }
}

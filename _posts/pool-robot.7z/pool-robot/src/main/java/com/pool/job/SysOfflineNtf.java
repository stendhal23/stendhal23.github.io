package com.pool.job;

import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.protobuf.PbClientMsg.SC_SYS_OFFLINE_NTF;

public class SysOfflineNtf extends Response {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		SC_SYS_OFFLINE_NTF msg = getMessage();
		LogUtil.SYSTEM.info("{} 连接断开! {}", this.robot.getName(), msg);
	}
}

package com.pool.job;

import com.pool.Response;

public class HeartbeatRs extends Response {

    @Override
    public void run() {
        //LogUtil.SYSTEM.info("ping {}ms", System.currentTimeMillis() - robot.getPingStart());
    }
}

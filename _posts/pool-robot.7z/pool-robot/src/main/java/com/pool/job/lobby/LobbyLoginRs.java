package com.pool.job.lobby;

import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.define.state.LobbyNetState;
import com.pool.protobuf.PbClientMsg.SC_LOBBY_LOGIN;
import com.pool.protobuf.PbCommonDef.PbLobbyRole;

public class LobbyLoginRs extends Response {
	@Override
	public void run() {
		SC_LOBBY_LOGIN msg = this.getMessage();
		robot.changeLobbyNs(LobbyNetState.LOGINED);
		robot.getData().setLoginRs(msg);

		PbLobbyRole role = robot.getData().getLoginRs().getRole();
		LogUtil.SYSTEM.info("{}{}登录成功!", role.getBasic().getNick(), role.getBasic().getUid());

		// relogin
		/*
		 * PbClientMsg.CS_lobby_relogin.Builder rq =
		 * PbClientMsg.CS_lobby_relogin.newBuilder(); rq.setToken(msg.getToken());
		 * robot.sendMsg(PbMsgCode.msgcode.CS_lobby_relogin.getNumber(), rq.build());
		 */
	}
}

package com.pool;

public interface IBehaviour {
    void run();
}
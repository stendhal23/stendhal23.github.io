package com.pool;

import com.google.protobuf.MessageLite;
import com.pool.common.util.LogUtil;
import com.pool.protobuf.PbCommonDef;
import com.pool.protobuf.PbMsgCode.msgcode;
import com.pool.robot.Robot;

public abstract class Response implements IResponse {
	protected Robot robot;
	private MessageLite message;

	public void success(MessageLite message) {
		this.message = message;
		run();
	}

	@SuppressWarnings("unchecked")
	public <T> T getMessage() {
		return (T) message;
	}

	public abstract void run();

	@Override
	public void error(int cmd, int errcode) {
		LogUtil.SYSTEM.error("{} {} 请求失败! {}", robot.getName(), msgcode.forNumber(cmd),
				PbCommonDef.errcode.forNumber(errcode));
	}

	@Override
	public void msg() {
	}

	public void init(Robot robot) {
		this.robot = robot;
	}

	public Robot getRobot() {
		return robot;
	}
}

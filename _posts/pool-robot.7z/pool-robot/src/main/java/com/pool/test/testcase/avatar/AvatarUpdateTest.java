package com.pool.test.testcase.avatar;

import com.google.protobuf.MessageLite;
import com.offbynull.coroutines.user.Continuation;
import com.pool.Response;
import com.pool.network.RobotNetNode;
import com.pool.protobuf.PbClientMsg;
import com.pool.protobuf.PbMsgCode;
import com.pool.test.core.Register;
import com.pool.test.core.TestCase;

import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

public class AvatarUpdateTest extends TestCase {


    @Override
    public void registerMsg(Register<MessageLite, Response> funcRegister) {
        funcRegister.register
                (PbMsgCode.msgcode.SC_UPDATE_AVATAR.getNumber(),
                        PbClientMsg.SC_UPDATE_AVATAR.getDefaultInstance(),
                        new UpdateAvatarRes());
    }

    @Override
    public void unRegisterMsg(Consumer<Integer> funcUnregister) {
        funcUnregister.accept(PbMsgCode.msgcode.SC_UPDATE_AVATAR.getNumber());
    }

    @Override
    public void doRunTests(Continuation c) {
        PbClientMsg.CS_UPDATE_AVATAR.Builder rq = PbClientMsg.CS_UPDATE_AVATAR.newBuilder();
        rq.setAvatar(123);
        client.sendMsg(PbMsgCode.msgcode.CS_UPDATE_AVATAR.getNumber(), rq.build());
    }


    //=========================
    private class UpdateAvatarRes extends TestCaseResponse {

        @Override
        public void run() {
            PbClientMsg.SC_UPDATE_AVATAR msg = this.getMessage();
            System.out.println(msg);

        }
    }

}

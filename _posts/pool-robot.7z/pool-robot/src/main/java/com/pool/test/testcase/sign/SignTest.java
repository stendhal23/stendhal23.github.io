package com.pool.test.testcase.sign;

import com.google.protobuf.MessageLite;
import com.offbynull.coroutines.user.Continuation;
import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.protobuf.PbClientMsg;
import com.pool.protobuf.PbCommonDef;
import com.pool.protobuf.PbCommonDef.errcode;
import com.pool.protobuf.PbMsgCode;
import com.pool.test.core.Register;
import com.pool.test.core.TestCase;
import org.junit.Assert;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.function.Consumer;

@SuppressWarnings("all")
public class SignTest extends TestCase {

    @Override
    public void registerMsg(Register<MessageLite, Response> funcRegister) {
        funcRegister.register
                (PbMsgCode.msgcode.SC_SIGN.getNumber(),
                        PbClientMsg.SC_SIGN.getDefaultInstance(),
                        new SignJobRes());
        funcRegister.register
                (PbMsgCode.msgcode.SC_AWARDS_LIST_NTF.getNumber(),
                        PbClientMsg.SC_AWARDS_LIST_NTF.getDefaultInstance(),
                        new AwardNTFJobRes());
    }

    @Override
    public void unRegisterMsg(Consumer<Integer> funcUnregister) {
        funcUnregister.accept(PbMsgCode.msgcode.SC_SIGN.getNumber());
        funcUnregister.accept(PbMsgCode.msgcode.SC_AWARDS_LIST_NTF.getNumber());
    }

    private long time(int year, int month, int day, int hour, int minute)
    {
        LocalDateTime time = LocalDateTime.of(year, month, day, hour, minute);
        return Timestamp.valueOf(time).getTime();
    }

    @Override
    public void doRunTests(Continuation c) throws InterruptedException{

        PbClientMsg.SC_AWARDS_LIST_NTF award;
        PbClientMsg.SC_SIGN response;
        errcode err;


        PbClientMsg.CS_SIGN.Builder rq = PbClientMsg.CS_SIGN.newBuilder();
        rq.setId(13);
        rq.setNow(time(2021, 7, 1, 18, 0));
        client.sendMsg(PbMsgCode.msgcode.CS_SIGN.getNumber(), rq.build());


        award = (PbClientMsg.SC_AWARDS_LIST_NTF) coroutine.yield(c);
        response = (PbClientMsg.SC_SIGN) coroutine.yield(c);

        Assert.assertEquals(2, award.getData(0).getType());
        Assert.assertEquals(200, award.getData(0).getValue());
        Assert.assertEquals(13, response.getSign().getId());
        Assert.assertEquals(Arrays.asList(0), response.getSign().getRewardHistoryList());


        //-------------------
        rq.setNow(time(2021, 7, 3, 12, 0));
        client.sendMsg(PbMsgCode.msgcode.CS_SIGN.getNumber(), rq.build());

        award = (PbClientMsg.SC_AWARDS_LIST_NTF) coroutine.yield(c);
        response = (PbClientMsg.SC_SIGN) coroutine.yield(c);

        Assert.assertEquals(1, award.getData(0).getType());
        Assert.assertEquals(12000, award.getData(0).getValue());
        Assert.assertEquals(13, response.getSign().getId());
        Assert.assertEquals(Arrays.asList(0, 2), response.getSign().getRewardHistoryList());


        //-------------------
        rq.setNow(time(2021, 7, 3, 10, 0));
        client.sendMsg(PbMsgCode.msgcode.CS_SIGN.getNumber(), rq.build());

        err = (errcode) coroutine.yield(c);
        Assert.assertEquals(errcode.INVALID_PARAM, err);



        //-------------------
        rq.setNow(time(2021, 7, 6, 20, 0));
        client.sendMsg(PbMsgCode.msgcode.CS_SIGN.getNumber(), rq.build());

        award = (PbClientMsg.SC_AWARDS_LIST_NTF) coroutine.yield(c);
        response = (PbClientMsg.SC_SIGN) coroutine.yield(c);

        Assert.assertEquals(10220, award.getData(0).getType());
        Assert.assertEquals(9, award.getData(0).getValue());
        Assert.assertEquals(13, response.getSign().getId());
        Assert.assertEquals(Arrays.asList(0, 2, 5), response.getSign().getRewardHistoryList());



        //-------------------
        rq.setNow(time(2021, 7, 10, 6, 0));
        client.sendMsg(PbMsgCode.msgcode.CS_SIGN.getNumber(), rq.build());

        award = (PbClientMsg.SC_AWARDS_LIST_NTF) coroutine.yield(c);
        response = (PbClientMsg.SC_SIGN) coroutine.yield(c);

        Assert.assertEquals(1, award.getData(0).getType());
        Assert.assertEquals(12000, award.getData(0).getValue());
        Assert.assertEquals(13, response.getSign().getId());
        Assert.assertEquals(Arrays.asList(2), response.getSign().getRewardHistoryList());


    }

    //================================================
    private class SignJobRes extends TestCaseResponse{


    }


    //================================================
    private class AwardNTFJobRes extends TestCaseResponse{


    }

}

package com.pool.robot;

import java.util.concurrent.atomic.AtomicLong;

import com.google.protobuf.MessageLite;
import com.pool.common.util.RandomUtil;
import com.pool.define.state.RoomNetState;
import com.pool.netclient.LobbyClient;
import com.pool.netclient.RoomClient;
import com.pool.netclient.TestCaseAwareLobbyClientDecorator;

public class Robot {
	private static AtomicLong nextRobotId = new AtomicLong(5000);

	private LobbyClient lobby = null;
	private RoomClient room = null;

	private final long id;
	private final String name;
	private Data data = new Data();

	public Robot() {
		this.id = nextRobotId.incrementAndGet();
		this.name = RandomUtil.generateUUID();

//		this.lobby = new LobbyClient(this);
		this.lobby = new TestCaseAwareLobbyClientDecorator(new LobbyClient(this));
	}

	public String getName() {
		return name;
	}

	public long getId() {
		return id;
	}

	public void run() {
		if (lobby != null) {
			lobby.run();
		}

		if (room != null) {
			room.run();
		}
	}

	public Data getData() {
		return data;
	}

	public void sendLobbyMsg(int code, MessageLite msg) {
		if (lobby != null) {
			lobby.sendMsg(code, msg);
		}
	}

	public void sendRoomMsg(int code, MessageLite msg) {
		if (room != null) {
			room.sendMsg(code, msg);
		}
	}

	public void changeLobbyNs(int state) {
		// TODO Auto-generated method stub
		if (lobby != null) {
			lobby.changeNs(state);
		}
	}

	public void changeLobbyAs(int state) {
		// TODO Auto-generated method stub
		if (lobby != null) {
			lobby.changeAs(state);
		}
	}

	public void changeRoomNs(int state) {
		// TODO Auto-generated method stub
		if (room != null) {
			room.changeNs(state);
		}
	}

	public void changeRoomAs(int state) {
		// TODO Auto-generated method stub
		if (room != null) {
			room.changeAs(state);
		}
	}

	public void startRoom() {
		// TODO Auto-generated method stub
		room = new RoomClient(this);
		room.changeNs(RoomNetState.CONNECTING);
	}
}

package com.pool.network;

import com.pool.common.packet.Packet;
import com.pool.common.util.LogUtil;

import com.pool.common.util.NettyUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;

public class RobotChannelHandler extends ChannelInboundHandlerAdapter {
    private RobotNetNode node;

    public RobotChannelHandler(RobotNetNode node) {
        this.node = node;
    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if (evt instanceof IdleStateEvent) {
            IdleStateEvent event = (IdleStateEvent) evt;
            // 服务器内部消息处理
            if (event.state().equals(IdleState.READER_IDLE)) {
                LogUtil.SYSTEM.debug("READER_IDLE {}", NettyUtil.getCtxBrieF(ctx));
                node.sessionTimeout(ctx);
            } else if (event.state().equals(IdleState.WRITER_IDLE)) {
                LogUtil.SYSTEM.debug("WRITER_IDLE {}", NettyUtil.getCtxBrieF(ctx));
                node.sessionTimeout(ctx);
            } else {
                LogUtil.SYSTEM.debug("ALL_IDLE {}", NettyUtil.getCtxBrieF(ctx));
            }
        }
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        LogUtil.SYSTEM.info("NewConnection {}", NettyUtil.getCtxBrieF(ctx));
        node.sessionActive(ctx);
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        LogUtil.SYSTEM.error("Disconnection {}", NettyUtil.getCtxBrieF(ctx));
        node.sessionInactive(ctx);
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        node.messageReceived(ctx, (Packet) msg);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        LogUtil.SYSTEM.error("ConnectionError {} ", NettyUtil.getCtxBrieF(ctx), cause);
        ctx.close();
    }
}

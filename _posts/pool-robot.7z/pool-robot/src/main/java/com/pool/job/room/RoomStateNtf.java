package com.pool.job.room;

import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.protobuf.PbClientMsg.SC_ROOM_STATE_NTF;
import com.pool.protobuf.PbCommonDef.PbeRoomState;

public class RoomStateNtf extends Response {
    @Override
    public void run() {
        SC_ROOM_STATE_NTF msg = getMessage();
        LogUtil.SYSTEM.info("{}收到通知,房间状态由{}切换到{}", robot.getData().getNick(), PbeRoomState.forNumber(msg.getOldState()),
                PbeRoomState.forNumber(msg.getNewState()));

        if (msg.getNewState() == PbeRoomState.ROOMSTATE_CLOSE.getNumber()) {// 房间关闭了
            LogUtil.SYSTEM.info("{}所在房间关闭了！！！", robot.getData().getNick());
            //robot.resetRoom();
        } else {
            //robot.setRoomState(msg.getNewState());
        }
    }
}

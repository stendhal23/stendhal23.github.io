package com.pool.test.testcase.video;

import com.google.protobuf.MessageLite;
import com.offbynull.coroutines.user.Continuation;
import com.pool.Response;
import com.pool.protobuf.PbClientMsg;
import com.pool.protobuf.PbCommonDef;
import com.pool.protobuf.PbMsgCode;
import com.pool.test.core.Register;
import com.pool.test.core.TestCase;
import org.junit.Assert;

import java.util.Optional;
import java.util.function.Consumer;

public class VideoTest extends TestCase{


    @Override
    public void registerMsg(Register<MessageLite, Response> funcRegister) {
        funcRegister.register
                (PbMsgCode.msgcode.SC_VIDEO_WATCHED.getNumber(),
                        PbClientMsg.SC_VIDEO_WATCHED.getDefaultInstance(),
                        new VideoWatchedRes());
        funcRegister.register
                (PbMsgCode.msgcode.SC_AWARDS_LIST_NTF.getNumber(),
                        PbClientMsg.SC_AWARDS_LIST_NTF.getDefaultInstance(),
                        new VideoTest.AwardNTFJobRes());
        funcRegister.register
                (PbMsgCode.msgcode.SC_TREASURE_DATA.getNumber(),
                        PbClientMsg.SC_TREASURE_DATA.getDefaultInstance(),
                        new VideoTest.TreasureGetRes());
    }

    @Override
    public void unRegisterMsg(Consumer<Integer> funcUnregister) {
        funcUnregister.accept(PbMsgCode.msgcode.SC_VIDEO_WATCHED.getNumber());
        funcUnregister.accept(PbMsgCode.msgcode.SC_AWARDS_LIST_NTF.getNumber());
        funcUnregister.accept(PbMsgCode.msgcode.SC_TREASURE_DATA.getNumber());
    }

    @Override
    public void doRunTests(Continuation c) throws Exception {

        PbClientMsg.CS_GM_CLEAN_MODULE.Builder rqCleanModules = PbClientMsg.CS_GM_CLEAN_MODULE.newBuilder();
        //-------------------
        rqCleanModules.setModule(-1);       // -1: ALL 2:RoleGoods, 3:RoleTreasure, 4: RoleSettings 5:RoleQuests 6:RoleCueStick 7:RoleArchive 8:RoleSign
        client.sendMsg(PbMsgCode.msgcode.CS_GM_CLEAN_MODULE.getNumber(), rqCleanModules.build());

        PbClientMsg.SC_AWARDS_LIST_NTF award;
        PbClientMsg.SC_VIDEO_WATCHED resVideoWatched;
        PbClientMsg.SC_TREASURE_DATA resTreasureGet;
        PbCommonDef.errcode err;


        PbClientMsg.CS_VIDEO_WATCHED.Builder rqVideoWatched = PbClientMsg.CS_VIDEO_WATCHED.newBuilder();
        PbClientMsg.CS_SIGN.Builder rqSign = PbClientMsg.CS_SIGN.newBuilder();
        PbClientMsg.CS_BUY_GOODS.Builder rqBuyGoods = PbClientMsg.CS_BUY_GOODS.newBuilder();
        PbClientMsg.CS_TREASURE_UNLOCK.Builder rqTreasureUnlock = PbClientMsg.CS_TREASURE_UNLOCK.newBuilder();
        PbClientMsg.CS_TREASURE_DATA.Builder rqTreasureGet = PbClientMsg.CS_TREASURE_DATA.newBuilder();
        PbClientMsg.CS_GM_RESOURCES.Builder rqGMResource = PbClientMsg.CS_GM_RESOURCES.newBuilder();

        //-------------------
        rqVideoWatched.setId(999999); //
        client.sendMsg(PbMsgCode.msgcode.CS_VIDEO_WATCHED.getNumber(), rqVideoWatched.build());

        err = (PbCommonDef.errcode) coroutine.yield(c);
        Assert.assertEquals(PbCommonDef.errcode.CONFIG_NOT_FOUND, err);

        //-------------------
        rqVideoWatched.setId(1001);        // 这个的策划配置奖励应该是 {"id":1001,"videoAwards":["1,100"]}   {"id":1002,"videoAwards":["2,3"]}
        client.sendMsg(PbMsgCode.msgcode.CS_VIDEO_WATCHED.getNumber(), rqVideoWatched.build());


        award = (PbClientMsg.SC_AWARDS_LIST_NTF) coroutine.yield(c);
        resVideoWatched = (PbClientMsg.SC_VIDEO_WATCHED) coroutine.yield(c);

        Assert.assertEquals(1, award.getData(0).getType());
        Assert.assertEquals(100, award.getData(0).getValue());
        Assert.assertEquals(1001, resVideoWatched.getVideo().getId());


        //--------------------
        rqVideoWatched.setId(1002);        // 这个的策划配置奖励应该是 {"id":1001,"videoAwards":["1,100"]}   {"id":1002,"videoAwards":["2,3"]}
        client.sendMsg(PbMsgCode.msgcode.CS_VIDEO_WATCHED.getNumber(), rqVideoWatched.build());


        award = (PbClientMsg.SC_AWARDS_LIST_NTF) coroutine.yield(c);
        resVideoWatched = (PbClientMsg.SC_VIDEO_WATCHED) coroutine.yield(c);

        Assert.assertEquals(2, award.getData(0).getType());
        Assert.assertEquals(3, award.getData(0).getValue());
        Assert.assertEquals(1002, resVideoWatched.getVideo().getId());
        Assert.assertEquals(0, resVideoWatched.getVideo().getCount());


        //------------------------------------- 非奖励类型


        //----------- 1) sign so we get some diamonds  2) buy treasure  3) unlock treasure
        rqSign.setId(13);
        rqSign.setNow(1625119200000L);   //{"ID":13,"Type":2,"StartTime":"1625119200000","DurationTime":999,"Rewards":["2,200","1003,1","1,12000","10220,4","21,5","10220,9","1003,3"]
        client.sendMsg(PbMsgCode.msgcode.CS_SIGN.getNumber(), rqSign.build());
        award = (PbClientMsg.SC_AWARDS_LIST_NTF) coroutine.yield(c);
        Assert.assertEquals(2, award.getData(0).getType());
        Assert.assertEquals(200, award.getData(0).getValue());

        rqBuyGoods.setId(101006);       // 从商店编号 101006 消耗钻石89个, 买3个商城高级宝箱 110003
        rqBuyGoods.setCount(1);
        client.sendMsg(PbMsgCode.msgcode.CS_BUY_GOODS.getNumber(), rqBuyGoods.build());

        award = (PbClientMsg.SC_AWARDS_LIST_NTF) coroutine.yield(c);
        Assert.assertEquals(110003, award.getData(0).getType());
        Assert.assertEquals(3, award.getData(0).getValue());

        rqTreasureUnlock.setPos(0);
        client.sendMsg(PbMsgCode.msgcode.CS_TREASURE_UNLOCK.getNumber(), rqTreasureUnlock.build());

            // 现在手上应该是没有宝箱的。
        client.sendMsg(PbMsgCode.msgcode.CS_TREASURE_DATA.getNumber(), rqTreasureGet.build());

        resTreasureGet = (PbClientMsg.SC_TREASURE_DATA) coroutine.yield(c);
        {
            Optional<PbCommonDef.PbTreasure> unlocked = resTreasureGet.getData().getDataMap().values().stream()
                    .filter(e -> e.getUnlock() > 0).findFirst();
            Assert.assertEquals(true, !unlocked.isPresent());
        }

            // gm 指令获得一个 cd 宝箱
        rqGMResource.setType(120003);   //120003 是个房间稀有宝箱, cd 为 14400 秒
        rqGMResource.setValue(1);
        client.sendMsg(PbMsgCode.msgcode.CS_GM_RESOURCES.getNumber(), rqGMResource.build());
        award = (PbClientMsg.SC_AWARDS_LIST_NTF) coroutine.yield(c);
        Assert.assertEquals(120003, award.getData(0).getType());
        Assert.assertEquals(1, award.getData(0).getValue());

            // 现在手上应该有一个宝箱了
        client.sendMsg(PbMsgCode.msgcode.CS_TREASURE_DATA.getNumber(), rqTreasureGet.build());
        resTreasureGet = (PbClientMsg.SC_TREASURE_DATA) coroutine.yield(c);
        {
            Optional<PbCommonDef.PbTreasure> unlocked = resTreasureGet.getData().getDataMap().values().stream()
                    .filter(e -> e.getUnlock() > 0).findFirst();
            // 此时宝箱还没有解锁
            Assert.assertEquals(true, !unlocked.isPresent());

            // 虽然没解锁, 但是存在
            Optional<PbCommonDef.PbTreasure> first = resTreasureGet.getData().getDataMap().values().stream()
                    .findFirst();
            Assert.assertEquals(true, first.isPresent());
            Assert.assertEquals(120003, first.get().getId());
            Assert.assertEquals(0, first.get().getPos());
            Assert.assertEquals(0, first.get().getUnlock());
        }

            // unlock it
        rqTreasureUnlock.setPos(0);
        client.sendMsg(PbMsgCode.msgcode.CS_TREASURE_UNLOCK.getNumber(), rqTreasureUnlock.build());

        client.sendMsg(PbMsgCode.msgcode.CS_TREASURE_DATA.getNumber(), rqTreasureGet.build());
        resTreasureGet = (PbClientMsg.SC_TREASURE_DATA) coroutine.yield(c);
        long unlockTime = 0;
        {
            Optional<PbCommonDef.PbTreasure> first = resTreasureGet.getData().getDataMap().values().stream()
                    .findFirst();
            Assert.assertEquals(120003, first.get().getId());
            Assert.assertEquals(0, first.get().getPos());
            Assert.assertTrue(first.get().getUnlock() > 0);
            unlockTime = first.get().getUnlock();
        }

            // watch video to reduce 宝箱 cd

                // {"id":1011,"Type":0,"videoAwards":[]},{"id":1012,"Type":2,"videoAwards":["7200"]}   TODO 商城宝箱是立刻开的, 怎么得到 CD 宝箱呢?
        rqVideoWatched.setId(1012);
        client.sendMsg(PbMsgCode.msgcode.CS_VIDEO_WATCHED.getNumber(), rqVideoWatched.build());

        resVideoWatched = (PbClientMsg.SC_VIDEO_WATCHED) coroutine.yield(c);
        Assert.assertEquals(1012, resVideoWatched.getVideo().getId());
        Assert.assertEquals(4, resVideoWatched.getVideo().getCount());

            // get it again, see if the cd is reduced
        client.sendMsg(PbMsgCode.msgcode.CS_TREASURE_DATA.getNumber(), rqTreasureGet.build());
        resTreasureGet = (PbClientMsg.SC_TREASURE_DATA) coroutine.yield(c);
        long newUnlockTime = 0;
        {
            Optional<PbCommonDef.PbTreasure> first = resTreasureGet.getData().getDataMap().values().stream()
                    .findFirst();
            Assert.assertEquals(120003, first.get().getId());
            Assert.assertEquals(0, first.get().getPos());
            Assert.assertTrue(first.get().getUnlock() > 0);
            newUnlockTime = first.get().getUnlock();
            Assert.assertEquals(7200*1000, unlockTime-newUnlockTime);
        }


         // watch video 1012 again, check remaining count
        rqVideoWatched.setId(1012);
        client.sendMsg(PbMsgCode.msgcode.CS_VIDEO_WATCHED.getNumber(), rqVideoWatched.build());

        resVideoWatched = (PbClientMsg.SC_VIDEO_WATCHED) coroutine.yield(c);
        Assert.assertEquals(1012, resVideoWatched.getVideo().getId());
        Assert.assertEquals(3, resVideoWatched.getVideo().getCount());

        rqVideoWatched.setId(1012);
        client.sendMsg(PbMsgCode.msgcode.CS_VIDEO_WATCHED.getNumber(), rqVideoWatched.build());

        resVideoWatched = (PbClientMsg.SC_VIDEO_WATCHED) coroutine.yield(c);
        Assert.assertEquals(1012, resVideoWatched.getVideo().getId());
        Assert.assertEquals(2, resVideoWatched.getVideo().getCount());

        rqVideoWatched.setId(1012);
        client.sendMsg(PbMsgCode.msgcode.CS_VIDEO_WATCHED.getNumber(), rqVideoWatched.build());

        resVideoWatched = (PbClientMsg.SC_VIDEO_WATCHED) coroutine.yield(c);
        Assert.assertEquals(1012, resVideoWatched.getVideo().getId());
        Assert.assertEquals(1, resVideoWatched.getVideo().getCount());

        rqVideoWatched.setId(1012);
        client.sendMsg(PbMsgCode.msgcode.CS_VIDEO_WATCHED.getNumber(), rqVideoWatched.build());

        resVideoWatched = (PbClientMsg.SC_VIDEO_WATCHED) coroutine.yield(c);
        Assert.assertEquals(1012, resVideoWatched.getVideo().getId());
        Assert.assertEquals(0, resVideoWatched.getVideo().getCount());

        rqVideoWatched.setId(1012);
        client.sendMsg(PbMsgCode.msgcode.CS_VIDEO_WATCHED.getNumber(), rqVideoWatched.build());

        err = (PbCommonDef.errcode) coroutine.yield(c);
        Assert.assertEquals(PbCommonDef.errcode.INVALID_OPERATION, err);



    }



    //================================================
    private class VideoWatchedRes extends TestCase.TestCaseResponse {}
    private class AwardNTFJobRes extends TestCaseResponse {}
    public class TreasureGetRes extends TestCaseResponse {}
}

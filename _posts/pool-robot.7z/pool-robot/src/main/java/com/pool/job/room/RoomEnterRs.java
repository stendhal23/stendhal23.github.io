package com.pool.job.room;

import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.define.state.RoomNetState;
import com.pool.protobuf.PbClientMsg.SC_ROOM_ENTER;
import com.pool.protobuf.PbCommonDef.PbRoom;

public class RoomEnterRs extends Response {
    @Override
    public void run() {
        SC_ROOM_ENTER msg = getMessage();
        PbRoom room = msg.getRoom();
        LogUtil.SYSTEM.info("{}进入房间成功,房间ID={}", robot.getData().getNick(), room.getRoomid());
        robot.getData().setEnterNtf(msg);
        robot.changeRoomNs(RoomNetState.ENTERED);
    }
    
    @Override
    public void error(int cmd, int errcode) {
    	robot.changeRoomNs(RoomNetState.CONNECTED);
    }
}

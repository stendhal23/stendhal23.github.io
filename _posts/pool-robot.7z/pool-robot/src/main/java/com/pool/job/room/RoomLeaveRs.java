package com.pool.job.room;

import com.pool.Response;
import com.pool.common.util.LogUtil;

public class RoomLeaveRs extends Response {
    @Override
    public void run() {        
        LogUtil.SYSTEM.info("{}离开房间", robot.getData().getNick());        
    }
}

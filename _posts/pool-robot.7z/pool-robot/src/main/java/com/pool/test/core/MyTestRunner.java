package com.pool.test.core;

import com.google.protobuf.MessageLite;
import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.network.RobotNetNode;
import com.pool.test.core.TestCase.TestCaseState;
import com.pool.test.testcase.quest.QuestTest;
import com.pool.test.testcase.quest.GuideTest;
import com.pool.test.testcase.sign.SignTest;
import com.pool.test.testcase.video.VideoTest;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class MyTestRunner {


    private List<TestCase> idleStateTest;
    private Register<MessageLite, Response> register;

    public MyTestRunner() {

        idleStateTest = new ArrayList<>();
        idleStateTest.add(new VideoTest());
        idleStateTest.add(new SignTest());
        idleStateTest.add(new QuestTest());
        idleStateTest.add(new GuideTest());

    }

    public void setRegister(Register<MessageLite, Response> funcRegister) {
        this.register = funcRegister;
    }


    private TestCase current;
    private int currentIdx;

    /**
     * is finished
     */
    public boolean testsInIdleState(RobotNetNode client, long id) {
        if(idleStateTest.isEmpty()) return true;
        current = idleStateTest.get(currentIdx);
        TestCaseState state = current.getState();

        boolean shouldRelease;
        if(state == TestCaseState.NEW){
            current.registerMsg(register);
            shouldRelease = false;
            current.runTests(client);
        } else if (state == TestCaseState.RUNNING) {
            shouldRelease = false;
            current.runTests(client);
        } else if (state == TestCaseState.FAIL) {
            current.unRegisterMsg(client::unRegisterMsg);
            shouldRelease = true;
            logTestResults("some idleStateTests FAILED", idleStateTest, id);
        } else if (state == TestCaseState.TIMEOUT) {
            current.unRegisterMsg(client::unRegisterMsg);
            shouldRelease = true;
            logTestResults("some idleStateTests TIMEOUT", idleStateTest, id);
        } else if (state == TestCaseState.SUCCESS) {
            this.currentIdx++;
            current.unRegisterMsg(client::unRegisterMsg);
            shouldRelease = currentIdx == idleStateTest.size();   // all test cases have run
            if(shouldRelease) {
                logTestResults("all idleStateTests success, cnt:" + cnt.incrementAndGet() , idleStateTest, id);
            }
        } else {
            throw new RobotTestStateException("impossible, must be bug");
        }

        return shouldRelease;

    }

    private static final AtomicInteger cnt = new AtomicInteger(0);

    private void logTestResults(String title, List<TestCase> testCases, long id) {

        LogUtil.SYSTEM.info("/=================================================/");
        LogUtil.SYSTEM.info("/== {} \uD83D\uDC4C", title);
        LogUtil.SYSTEM.info("/== id: {}", id);
        for (TestCase testCase : testCases) {
            String reason = "";
            if(testCase.getState() != TestCaseState.SUCCESS) reason = testCase.reason;
            LogUtil.SYSTEM.info("/== {} {} {}", testCase.getClass().getSimpleName(), testCase.getState().getEmoji(), reason);
        }
        LogUtil.SYSTEM.info("/=================================================/");
    }


}

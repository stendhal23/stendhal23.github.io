package com.pool.job.room;

import com.pool.Response;
import com.pool.common.util.LogUtil;
import com.pool.protobuf.PbClientMsg.SC_ROOM_LEAVE_NTF;

public class LeaveRoomNtf extends Response {
    @Override
    public void run() {
        SC_ROOM_LEAVE_NTF msg = getMessage();
        LogUtil.SYSTEM.info("{}收到通知,uid={}的玩家离开房间", robot.getData().getNick(), msg.getRoleid());
    }
}

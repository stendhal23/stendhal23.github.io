package com.pool.main;

import com.pool.RobotHub;
import com.pool.common.util.LogUtil;
import com.pool.properties.ServerProperties;

public class RobotApp {
	public static void initAppBootParams() {
		// 初始化启动参数
		if (System.getProperty("app.server.rootpath") == null) {
			System.setProperty("app.server.rootpath", System.getProperty("user.dir"));
		}
		if (System.getProperty("app.server.logpath") == null) {
			System.setProperty("app.server.logpath", System.getProperty("user.dir") + "/log");
		}
	}

	public static void main(String[] args) throws Exception {
		initAppBootParams();		
		LogUtil.init();
		ServerProperties.load(System.getProperty("sp", "conf/server.properties"));
		RobotHub.getInstance().start(ServerProperties.WORK_THREAD, ServerProperties.ROBOT_NUM);
	}
}

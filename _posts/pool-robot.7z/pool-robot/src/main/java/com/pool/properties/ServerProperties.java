package com.pool.properties;

import com.pool.common.common.JProperties;

public class ServerProperties {
	// 系统
	public static String APP_NAME; // 客户端名

	public static int WORK_THREAD; // 线程数量

	public static int ROBOT_NUM; // 机器人数量

	public static int TASK_TIMEOUT;
	public static int ROOM_KEEPALIVE;// 游戏心跳频率

	public static String AUTH_URL;
	
	public static void load(String path) {
		try {
			JProperties serverSettings = new JProperties(path);

			APP_NAME = serverSettings.getProperty("APP_NAME", "App");
			WORK_THREAD = Integer.parseInt(serverSettings.getProperty("WORK_THREAD", "10"));
			ROBOT_NUM = Integer.parseInt(serverSettings.getProperty("ROBOT_NUM", "100"));

			TASK_TIMEOUT = serverSettings.getIntProperty("TASK_TIMEOUT", 30000);
			ROOM_KEEPALIVE = serverSettings.getIntProperty("ROOM_KEEPALIVE", 5);
			
			AUTH_URL = serverSettings.getProperty("AUTH_URL", "");
		} catch (Exception e) {
			throw new Error("Failed to load " + path);
		}
	}
}

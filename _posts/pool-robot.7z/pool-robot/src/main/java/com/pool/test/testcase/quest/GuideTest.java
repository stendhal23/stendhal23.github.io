package com.pool.test.testcase.quest;

import com.google.protobuf.MessageLite;
import com.offbynull.coroutines.user.Continuation;
import com.pool.Response;
import com.pool.protobuf.PbClientMsg;
import com.pool.protobuf.PbCommonDef.errcode;
import com.pool.protobuf.PbMsgCode;
import com.pool.test.core.Register;
import com.pool.test.core.TestCase;
import org.junit.Assert;

import java.util.function.Consumer;

public class GuideTest extends TestCase{

    @Override
    public void registerMsg(Register<MessageLite, Response> funcRegister) {
        funcRegister.register
                (PbMsgCode.msgcode.SC_GUIDE_COMPLETE.getNumber(),
                        PbClientMsg.SC_GUIDE_COMPLETE.getDefaultInstance(),
                        new GuideTest.GuideCompleteRes());
        funcRegister.register
                (PbMsgCode.msgcode.SC_AWARDS_LIST_NTF.getNumber(),
                        PbClientMsg.SC_AWARDS_LIST_NTF.getDefaultInstance(),
                        new GuideTest.AwardNTFJobRes());
    }

    @Override
    public void unRegisterMsg(Consumer<Integer> funcUnregister) {
        funcUnregister.accept(PbMsgCode.msgcode.SC_GUIDE_COMPLETE.getNumber());
        funcUnregister.accept(PbMsgCode.msgcode.SC_AWARDS_LIST_NTF.getNumber());
    }

    @Override
    public void doRunTests(Continuation c) throws Exception {

        PbClientMsg.SC_AWARDS_LIST_NTF award;
        PbClientMsg.SC_GUIDE_COMPLETE respGuideComplete;
        errcode err;


        PbClientMsg.CS_GUIDE_COMPLETE.Builder rqGuideComplete = PbClientMsg.CS_GUIDE_COMPLETE.newBuilder();

        //-------------------
        rqGuideComplete.setId(987654321); //
        client.sendMsg(PbMsgCode.msgcode.CS_GUIDE_COMPLETE.getNumber(), rqGuideComplete.build());

        err = (errcode) coroutine.yield(c);
        Assert.assertEquals(errcode.CONFIG_NOT_FOUND, err);

        //-------------------
        rqGuideComplete.setId(1000);        // 这个的策划配置奖励应该是 [{"ID":1000,"Awards":["100001,1"]}]
        client.sendMsg(PbMsgCode.msgcode.CS_GUIDE_COMPLETE.getNumber(), rqGuideComplete.build());


        award = (PbClientMsg.SC_AWARDS_LIST_NTF) coroutine.yield(c);
        respGuideComplete = (PbClientMsg.SC_GUIDE_COMPLETE) coroutine.yield(c);

        Assert.assertEquals(100001, award.getData(0).getType());
        Assert.assertEquals(1, award.getData(0).getValue());
        Assert.assertEquals(1000, respGuideComplete.getId());

        //-------------------
        rqGuideComplete.setId(1000);
        client.sendMsg(PbMsgCode.msgcode.CS_GUIDE_COMPLETE.getNumber(), rqGuideComplete.build());

        err = (errcode) coroutine.yield(c);
        Assert.assertEquals(errcode.INVALID_PARAM, err);


        //--------------------
        rqGuideComplete.setId(1000);
        client.sendMsg(PbMsgCode.msgcode.CS_GUIDE_COMPLETE.getNumber(), rqGuideComplete.build());

        err = (errcode) coroutine.yield(c);
        Assert.assertEquals(errcode.INVALID_PARAM, err);



    }


    //================================================
    private class GuideCompleteRes extends TestCase.TestCaseResponse {}
    private class AwardNTFJobRes extends TestCaseResponse {}
}

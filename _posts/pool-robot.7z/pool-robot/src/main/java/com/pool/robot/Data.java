package com.pool.robot;

import com.pool.define.LoginResponse;
import com.pool.protobuf.PbClientMsg.SC_LOBBY_LOGIN;
import com.pool.protobuf.PbClientMsg.SC_ROOM_ENTER;
import com.pool.protobuf.PbClientMsg.SC_SEARCH_PLAYER_NTF;

public class Data {

	private LoginResponse authRs;
	private SC_LOBBY_LOGIN loginRs;
	private SC_SEARCH_PLAYER_NTF searchNtf;
	private SC_ROOM_ENTER enterNtf;

	public long getUid() {
		return loginRs.getRole().getBasic().getUid();
	}

	public String getNick() {
		return loginRs.getRole().getBasic().getNick() + loginRs.getRole().getBasic().getUid();
	}

	public SC_SEARCH_PLAYER_NTF getSearchNtf() {
		return searchNtf;
	}

	public void setSearchNtf(SC_SEARCH_PLAYER_NTF msg) {
		this.searchNtf = msg;
	}

	public SC_LOBBY_LOGIN getLoginRs() {
		return loginRs;
	}

	public void setLoginRs(SC_LOBBY_LOGIN msg) {
		this.loginRs = msg;
	}

	public LoginResponse getAuthRs() {
		return authRs;
	}

	public void setAuthRs(LoginResponse authRs) {
		this.authRs = authRs;
	}

	public SC_ROOM_ENTER getEnterNtf() {
		return enterNtf;
	}

	public void setEnterNtf(SC_ROOM_ENTER enterNtf) {
		this.enterNtf = enterNtf;
	}
}

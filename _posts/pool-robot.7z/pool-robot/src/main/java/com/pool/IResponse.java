package com.pool;

public interface IResponse {
     // 请求失败
    void error(int cmd, int errcode);

    // 请求回执
    void msg();
}

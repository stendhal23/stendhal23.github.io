package com.pool.job.lobby;

import com.pool.Response;
import com.pool.protobuf.PbClientMsg;

public class SettingsUpdateRs extends Response {


    @Override
    public void run() {
        PbClientMsg.SC_LOBBY_ROLE_DATA_SETTINGS_UPDATE msg = this.getMessage();

        System.out.println(msg);
    }
}

package com.pool.netclient;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.protobuf.MessageLite;
import com.pool.IBehaviour;
import com.pool.Response;
import com.pool.common.actor.ICallback;
import com.pool.common.http.HttpUtil;
import com.pool.common.util.LogUtil;
import com.pool.common.util.RandomUtil;
import com.pool.define.LoginResponse;
import com.pool.define.state.LobbyActionState;
import com.pool.define.state.LobbyNetState;
import com.pool.job.HeartbeatRs;
import com.pool.job.SysOfflineNtf;
import com.pool.job.lobby.*;
import com.pool.network.RobotNetNode;
import com.pool.properties.ServerProperties;
import com.pool.protobuf.PbClientMsg;
import com.pool.protobuf.PbClientMsg.CS_LOBBY_LOGIN;
import com.pool.protobuf.PbClientMsg.CS_ROOM_CHECK_IN;
import com.pool.protobuf.PbClientMsg.CS_SEARCH_PLAYER;
import com.pool.protobuf.PbClientMsg.CS_SYS_HEARTBEAT;
import com.pool.protobuf.PbClientMsg.SC_LOBBY_LOGIN;
import com.pool.protobuf.PbClientMsg.SC_ROOM_CHECK_IN;
import com.pool.protobuf.PbClientMsg.SC_SEARCH_PLAYER;
import com.pool.protobuf.PbClientMsg.SC_SEARCH_PLAYER_NTF;
import com.pool.protobuf.PbClientMsg.SC_SYS_HEARTBEAT;
import com.pool.protobuf.PbClientMsg.SC_SYS_OFFLINE_NTF;
import com.pool.protobuf.PbMsgCode.msgcode;
import com.pool.robot.Robot;

import io.netty.channel.ChannelHandlerContext;

import java.util.concurrent.atomic.AtomicInteger;

public class LobbyClient extends RobotNetNode {
	private Behaviour behaviour = new Behaviour();
	protected Robot robot;

	// 账号数据
	private String userId;

	// time
	private long pingTime;
	private long authTime;
	private long connectTime;
	private long loginTime = 0;

	private int nstateValue;

	private int actionState;
	private long actionTime;

	public LobbyClient(Robot robot) {
		this.robot = robot;
		this.initMsg();
	}




	@Override
	protected void initMsg() {
		registerMsg(msgcode.SC_SYS_OFFLINE_NTF.getNumber(), SC_SYS_OFFLINE_NTF.getDefaultInstance(),
				new SysOfflineNtf(), robot);
		registerMsg(msgcode.SC_SYS_HEARTBEAT.getNumber(), SC_SYS_HEARTBEAT.getDefaultInstance(), new HeartbeatRs(),
				robot);
		registerMsg(msgcode.SC_LOBBY_LOGIN.getNumber(), SC_LOBBY_LOGIN.getDefaultInstance(), new LobbyLoginRs(), robot);
		registerMsg(msgcode.SC_SEARCH_PLAYER.getNumber(), SC_SEARCH_PLAYER.getDefaultInstance(), new SearchPlayerRs(),
				robot);
		registerMsg(msgcode.SC_SEARCH_PLAYER_NTF.getNumber(), SC_SEARCH_PLAYER_NTF.getDefaultInstance(),
				new SearchPlayerNtf(), robot);
		registerMsg(msgcode.SC_ROOM_CHECK_IN.getNumber(), SC_ROOM_CHECK_IN.getDefaultInstance(), new RoomCheckInRs(),
				robot);
		registerMsg(msgcode.SC_LOBBY_ROLE_DATA_SETTINGS_UPDATE.getNumber(), PbClientMsg.SC_LOBBY_ROLE_DATA_SETTINGS_UPDATE.getDefaultInstance(), new SettingsUpdateRs(),
				robot);


	}



	public void run() {
		handleMsg();

		ping();

		switch (this.nstateValue) {
		case LobbyNetState.AUTHING:
			nstateAuth();
			break;
		case LobbyNetState.CONNECTING:
			nstateConnecting();
			break;
		case LobbyNetState.CONNECTED:
			nstateConnected();
			break;
		case LobbyNetState.LOGINED:
			nstateLogined();
			break;
		case LobbyNetState.CLOSING:
			nstateClosing();
			break;
		}
	}

	private static final AtomicInteger robotId = new AtomicInteger(0);

	public String getUserId() {
		if (this.userId == null) {
//			this.userId = RandomUtil.generateUUID();
			this.userId = "robot_" + robotId.getAndIncrement();
		}
		return userId;
	}

	public void changeNs(int state) {
		this.nstateValue = state;
	}

	private void ping() {
		if (System.currentTimeMillis() >= this.pingTime + 5000) {
			CS_SYS_HEARTBEAT.Builder rq = CS_SYS_HEARTBEAT.newBuilder();
			this.sendMsg(msgcode.CS_SYS_HEARTBEAT.getNumber(), rq.build());
			this.pingTime = System.currentTimeMillis();
		}
	}

	private void nstateAuth() {
		if (System.currentTimeMillis() < authTime + 3000) {
			return;
		}
		authTime = System.currentTimeMillis();

		JSONObject param = new JSONObject();
		param.put("userId", this.getUserId());

		String result = HttpUtil.sendJsonString(ServerProperties.AUTH_URL, param.toJSONString());
		if (result == null) {
			return;
		}

		JSONObject resp = JSON.parseObject(result);
		int code = resp.getIntValue("code");
		String msg = resp.getString("msg");
		JSONObject data = resp.getJSONObject("data");
		if (code == 0) {
			LogUtil.SYSTEM.info("账号登录成功");
		} else {
			LogUtil.SYSTEM.info("账号登录失败,{},{}", code, msg);
			return;
		}
		this.robot.getData().setAuthRs(JSON.parseObject(data.toJSONString(), LoginResponse.class));
		//TODO
		this.robot.getData().getAuthRs().setLobbyHost("10.10.9.42:18008");

		changeNs(LobbyNetState.CONNECTING);
		LogUtil.SYSTEM.info(data);
	}

	@Override
	protected byte[] getHeader() {
		int lobby = robot.getData().getAuthRs().getLobby();
		return toByteArray(lobby);
	}

	public byte[] toByteArray(int value) {
		return new byte[] {
				(byte)(value >> 24),
				(byte)(value >> 16),
				(byte)(value >> 8),
				(byte)value};
	}

	private void nstateConnecting() {
		if (System.currentTimeMillis() >= this.connectTime + 5000) {
			this.connectTime = System.currentTimeMillis();
			String[] host = robot.getData().getAuthRs().getLobbyHost().split(":");
			this.host = host[0];
			this.port = Integer.parseInt(host[1]);
			this.startConnect(new ICallback() {
				@Override
				public void onResult(Object x) {
					// TODO Auto-generated method stub
					changeNs(LobbyNetState.CONNECTED);
					LogUtil.SYSTEM.info("{} 连接LOBBY服务器成功.", robot.getName());
				}
			});
		}
	}

	private void nstateConnected() {
		if (System.currentTimeMillis() >= loginTime + 5000) {
			loginTime = System.currentTimeMillis();
			CS_LOBBY_LOGIN.Builder rq = CS_LOBBY_LOGIN.newBuilder();
			rq.setParam(this.robot.getData().getAuthRs().getParam());
			// 测试
			sendMsg(msgcode.CS_LOBBY_LOGIN.getNumber(), rq.build());
			LogUtil.SYSTEM.info("{} login {}", robot.getName(), rq);
		}
	}

	private void nstateClosing() {
		this.reset();
		changeNs(LobbyNetState.CONNECTING);
	}

	public void sessionInactive(ChannelHandlerContext ctx) {
		LogUtil.SYSTEM.info("{} 断开连接.", robot.getName());
		this.reset();
	}

	private void nstateLogined() {
		switch (this.actionState) {
		case LobbyActionState.ROOM_GAME:
			break;
		case LobbyActionState.SEARCHING:
			actionSearching();
			break;
		case LobbyActionState.SEARCH_SUCCESS:
			actionSearchSuccess();
			break;
		case LobbyActionState.ROOM_CHECK_IN:
			actionRoomCheckIn();
			break;
		case LobbyActionState.ROOM_CHECK_IN_SUCCESS:
			actionRoomCheckInSuccess();
			break;
		case LobbyActionState.IDLE:
		default:
			actionIdle();
			break;
		}
	}

	public void changeAs(int state) {
		this.actionState = state;
		this.actionTime = System.currentTimeMillis();
	}

	protected void actionIdle() {


		behaviour.exec(new IBehaviour() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				CS_SEARCH_PLAYER.Builder rq = CS_SEARCH_PLAYER.newBuilder();
				rq.setGameId(1001);
				rq.setVersion("1");
				sendMsg(msgcode.CS_SEARCH_PLAYER.getNumber(), rq.build());
				LogUtil.SYSTEM.info("{}请求匹配", robot.getData().getNick());

				changeAs(LobbyActionState.SEARCHING);
			}
		});
	}

	private void actionSearching() {
		if (System.currentTimeMillis() >= this.actionTime + 40000) {
			// 取消
		}
	}

	private void actionSearchSuccess() {
		behaviour.exec(new IBehaviour() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				CS_ROOM_CHECK_IN.Builder msg = CS_ROOM_CHECK_IN.newBuilder();
				sendMsg(msgcode.CS_ROOM_CHECK_IN.getNumber(), msg.build());
				changeAs(LobbyActionState.ROOM_CHECK_IN);
			};
		});
	}

	private void actionRoomCheckIn() {
		// TODO Auto-generated method stub
		if (System.currentTimeMillis() >= this.actionTime + 40000) {
			// 取消
		}
	}

	private void actionRoomCheckInSuccess() {
		behaviour.exec(new IBehaviour() {
			@Override
			public void run() {
				// 建立ROOM连接,并发起ROOM登录请求
				robot.startRoom();
				changeAs(LobbyActionState.ROOM_GAME);
			}
		});

	}

}
